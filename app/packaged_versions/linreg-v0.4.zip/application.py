from dash import Dash, Input, Output, State, html, dcc
import dash
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import imageio
import os

def mse(df, b0, b1):
    mean = 0
    for index, row in df.iterrows():
        mean += pow(row['y'] - (b0 + b1 * row['x']),2)
    mean /= df.shape[0]
    return mean

def make_fig(df, b0, b1, max_epochs, epoch):
    range_x_wt = 0.1 * (df['x'].max() - df['x'].min())
    lsrl_x = np.linspace(df['x'].min() - range_x_wt,df['x'].max() + range_x_wt,100)
    scatter = px.scatter(data_frame=df,x='x',y='y')
    lsrl = px.line(x=lsrl_x,y=b0+b1*lsrl_x)
    fig = go.Figure(data=scatter.data + lsrl.data,layout={
                                                            'title': {'text': ('Epoch {epoch:' + str(len(str(max_epochs))) + 'd}<br>Mean Squared Error: {mse:.6f}<br>Predicted LSRL: {beta0:.4f} ' + ('+' if b1 > 0 else '-') + ' {beta1:.4f}x').format(epoch=epoch,mse=mse(df,b0,b1),beta0=b0,beta1=abs(b1)), 'x': 0.5},
                                                            'xaxis': {'title': 'x'},
                                                            'yaxis': {'title': 'y'}
                                                  })
    fig.update_xaxes(range=[df['x'].min() - range_x_wt,df['x'].max() + range_x_wt])
    range_y_wt = 0.1 * (df['y'].max() - df['y'].min())
    fig.update_yaxes(range=[df['y'].min() - range_y_wt,df['y'].max() + range_y_wt])
    return fig

def iterate(df, b0_start=1, b1_start=1, max_epochs=100, learning_rate=0.1, start=0, append=False):
    # print(max_epochs)
    n = df.shape[0]
    b0 = b0_start
    b1 = b1_start
    figs = [make_fig(df=df,b0=b0,b1=b1,max_epochs=max_epochs,epoch=start)] if not append else []
    for i in range(start + 1,max_epochs + 1):
        db0 = db1 = 0
        for index, row in df.iterrows():
            db0 += row['y'] - (b0 + b1 * row['x'])
            db1 += (row['y'] - (b0 + b1 * row['x'])) * row['x']
        db0 *= -2 / n
        db1 *= -2 / n
        b0 -= learning_rate * db0
        b1 -= learning_rate * db1
        figs.append(make_fig(df=df,b0=b0,b1=b1,max_epochs=max_epochs,epoch=i))
    return b0, b1, figs

def make_gif(figs, filepath):
    i = 0
    for f in figs:
        print('making image ' + str(i))
        f.write_image('temp_{index}.png'.format(index=i),format='png',engine='kaleido')
        i += 1
    with imageio.get_writer(filepath,mode='I') as writer:
        for j in range(len(figs)):
            path = 'temp_{index}.png'.format(index=j)
            writer.append_data(imageio.imread(path))
            os.remove(path)

app = Dash(__name__)
application = app.server

df = pd.DataFrame({
    'x': [0,1,2,3,4,5],
    'y': [6,4,3,3,1,0]
})

# max_epochs_default is only to be used in the first rendering of the website. Do NOT assign it afterwards
max_epochs_default = 100
max_epochs = max_epochs_default
# same with this default
learning_rate_default = 0.1
learning_rate = learning_rate_default
gif_filepath = 'figure.gif'

beta0, beta1, figures = iterate(df,1,1,max_epochs_default,learning_rate_default)
#make_gif(figs,gif_filepath)

app.layout = html.Div(className='body',children=[
    html.Center(children=[
        html.H3(children='An Implementation of Linear Regression Using Gradient Descent'),
        html.Div(children=[
            html.H5(children='Victor Nguyen')
        ],style={'padding-bottom': '10px'}),
        html.P(id='learning-rate-label',children='Learning Rate: 0.1'),
        # html.Button(id='download-button',className='waves-effect waves-light btn',children='Download GIF'),
        # dcc.Download(id='download-gif')
    ]),
    dcc.Graph(id='scatter-plot'),
    dcc.Slider(
        id='epoch-slider',
        min=0,
        max=max_epochs_default,
        step=1,
        value=0,
        marks={str(z): str(z) for z in range(0,max_epochs_default + 1,max_epochs_default // 10)}
    ),
    html.Div(className='row',children=[
        html.Div(className='col s3 offset-s3',children=[
            dcc.Input(
                id='max-epochs-input',
                type='text',
                value=100
            ),
            html.Label(htmlFor='max-epochs-input',children='Max Epochs'),
        ]),
        html.Div(className='col s3',children=[
            dcc.Input(
                id='learning-rate-input',
                type='text',
                value=0.1
            ),
            html.Label(htmlFor='learning-rate-input',children='Learning Rate')
        ])
    ]),
    html.Center(children=[
        html.Button(id='generate-button',className='waves-effect waves-light btn',children='Generate Graph')
    ])
])

@app.callback(
    Output(component_id='scatter-plot',component_property='figure'),
    Input(component_id='epoch-slider',component_property='value')
)
def update_epoch(epoch):
    return figures[epoch]

# @app.callback(
#     Output(component_id='download-gif',component_property='data'),
#     Input(component_id='download-button',component_property='n_clicks'),
#     prevent_initial_call=True
# )
# def download_gif(n_clicks):
#     return dcc.send_file(gif_filepath)

@app.callback(
    Output(component_id='epoch-slider',component_property='max'),
    Output(component_id='epoch-slider',component_property='marks'),
    Input(component_id='generate-button',component_property='n_clicks'),
    State(component_id='max-epochs-input',component_property='value'),
    prevent_initial_call=True
)
def update_max_epochs(n_clicks, new_max):
    global beta0, beta1, figures, max_epochs
    try:
        new_max = int(new_max)
        if new_max <= 0 or new_max == max_epochs:
            return dash.no_update
    except:
        return dash.no_update
    # calculate new figs
    if new_max > max_epochs:
        beta0, beta1, temp = iterate(df,beta0,beta1,new_max,learning_rate_default,start=len(figures) - 1,append=True)
        figures.extend(temp)
    max_epochs = new_max
    # change slider
    return new_max, {str(z): str(z) for z in range(0,new_max + 1,new_max // 10)}

@app.callback(
    Output(component_id='learning-rate-label',component_property='children'),
    Input(component_id='generate-button',component_property='n_clicks'),
    State(component_id='learning-rate-input',component_property='value'),
    prevent_initial_call=True
)
def update_learning_rate(n_clicks, new_lr):
    global beta0, beta1, figures, learning_rate
    try:
        new_lr = float(new_lr)
        if new_lr < 0 or new_lr == learning_rate:
            return dash.no_update
    except:
        return dash.no_update
    print(new_lr)
    learning_rate = new_lr
    beta0, beta1, figures = iterate(df,1,1,max_epochs,new_lr)
    return 'Learning Rate: {}'.format(new_lr)

if __name__ == '__main__':
    # For running locally
    # app.run_server(debug=True,port=8080)
    # For deployment
    application.run(port=8080)