from dash import Dash, Input, Output, html, dcc
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
import numpy as np
import imageio
import os

def mse(df, b0, b1):
    mean = 0
    for index, row in df.iterrows():
        mean += pow(row['y'] - (b0 + b1 * row['x']),2)
    mean /= df.shape[0]
    return mean

def make_fig(df, b0, b1, max_epochs, epoch):
    range_x_wt = 0.1 * (df['x'].max() - df['x'].min())
    lsrl_x = np.linspace(df['x'].min() - range_x_wt,df['x'].max() + range_x_wt,100)
    scatter = px.scatter(data_frame=df,x='x',y='y')
    lsrl = px.line(x=lsrl_x,y=b0+b1*lsrl_x)
    fig = go.Figure(data=scatter.data + lsrl.data,layout={
                                                            'title': {'text': ('Epoch {epoch:' + str(len(str(max_epochs))) + 'd}<br>Mean Squared Error: {mse:.6f}<br>Predicted LSRL: {beta0:.4f} ' + ('+' if b1 > 0 else '-') + ' {beta1:.4f}x').format(epoch=epoch,mse=mse(df,b0,b1),beta0=b0,beta1=abs(b1)), 'x': 0.5},
                                                            'xaxis': {'title': 'x'},
                                                            'yaxis': {'title': 'y'}
                                                  })
    fig.update_xaxes(range=[df['x'].min() - range_x_wt,df['x'].max() + range_x_wt])
    range_y_wt = 0.1 * (df['y'].max() - df['y'].min())
    fig.update_yaxes(range=[df['y'].min() - range_y_wt,df['y'].max() + range_y_wt])
    return fig

def iterate(df, b0_start=1, b1_start=1, max_epochs=100, learning_rate=0.1):
    n = df.shape[0]
    b0 = b0_start
    b1 = b1_start
    figs = [make_fig(df=df,b0=b0,b1=b1,max_epochs=max_epochs,epoch=0)]
    for i in range(1,max_epochs + 1):
        db0 = db1 = 0
        for index, row in df.iterrows():
            db0 += row['y'] - (b0 + b1 * row['x'])
            db1 += (row['y'] - (b0 + b1 * row['x'])) * row['x']
        db0 *= -2 / n
        db1 *= -2 / n
        b0 -= learning_rate * db0
        b1 -= learning_rate * db1
        figs.append(make_fig(df=df,b0=b0,b1=b1,max_epochs=max_epochs,epoch=i))
    return figs

def make_gif(figs, filepath):
    i = 0
    for f in figs:
        print('making image ' + str(i))
        f.write_image('temp_{index}.png'.format(index=i),format='png',engine='kaleido')
        i += 1
    with imageio.get_writer(filepath,mode='I') as writer:
        for j in range(len(figs)):
            path = 'temp_{index}.png'.format(index=j)
            writer.append_data(imageio.imread(path))
            os.remove(path)

app = Dash(__name__)

df = pd.DataFrame({
    'x': [0,1,2,3,4,5],
    'y': [6,4,3,3,1,0]
})

max_epochs = 100
learning_rate = 0.1
gif_filepath = 'figure.gif'

figs = iterate(df,1,1,max_epochs,learning_rate)
#make_gif(figs,gif_filepath)

app.layout = html.Div(children=[
    html.Center(children=[
        html.H1(children='An Implementation of Linear Regression Using Gradient Descent'),
        html.Div(children=[
            html.H3(children='Author: Victor Nguyen')
        ],style={'padding-bottom': '10px'}),
        html.P(children='Learning Rate: 0.1'),
        html.Button(id='download-button',children='Download GIF'),
        dcc.Download(id='download-gif')
    ]),
    dcc.Graph(id='scatter-plot'),
    dcc.Slider(
        id='epoch-slider',
        min=0,
        max=max_epochs,
        step=1,
        value=0,
        marks={str(z): str(z) for z in range(0,max_epochs + 1,max_epochs // 10)}
    )
])

@app.callback(
    Output(component_id='scatter-plot',component_property='figure'),
    Input(component_id='epoch-slider',component_property='value')
)
def update_epoch(epoch):
    return figs[epoch]

@app.callback(
    Output(component_id='download-gif',component_property='data'),
    Input(component_id='download-button',component_property='n_clicks'),
    prevent_initial_call=True
)
def download_gif(n_clicks):
    return dcc.send_file(gif_filepath)

if __name__ == '__main__':
    app.run_server(debug=True,port=8080)